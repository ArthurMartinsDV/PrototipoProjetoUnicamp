import * as React from 'react';
import {
  View,
  Text,
  Image,
  Pressable,
  TextInput,
  ScrollView,
} from 'react-native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import { useWindowDimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Card, Title } from 'react-native-paper';

const Drawer = createDrawerNavigator();

function Login({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center' }}>
      <LinearGradient
        style={{
          alignItems: 'center',
          position: 'absolute',
          left: 0,
          right: 0,
          top: 0,
          height: '100%',
        }}
        colors={['#ffffff', '#ffffff', '#AE040F']}>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Image
          source={require('./imagens/logo.png')}
          style={{
            height: 150,
            width: 230,
            resizeMode: 'stretch',
            paddingTop: 70,
          }}
        />
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>

        <Text style={{ fontSize: 25, padding: 20 }}>
          Entre ou crie uma conta
        </Text>
        <Text></Text>
        <Pressable
          onPress={() => navigation.navigate('Entrar')}
          style={{
            margin: 10,
            padding: 15,
            borderRadius: 10,
            backgroundColor: 'rgba(255,255,255,0.5)',
            width: 300,
          }}>
          <Text style={{ textAlign: 'center', fontSize: 22 }}>Entrar</Text>
        </Pressable>
        <Pressable
          onPress={() => navigation.navigate('Cadastrar')}
          style={{
            padding: 15,
            borderRadius: 10,
            backgroundColor: 'rgba(255,255,255,0.5)',
            width: 300,
          }}>
          <Text style={{ textAlign: 'center', fontSize: 22 }}>
            Cadastrar-se
          </Text>
        </Pressable>
      </LinearGradient>
    </View>
  );
}

function Entrar({ navigation }) {
  const [usuario, svusuario] = React.useState('');
  const [senha, svsenha] = React.useState('');
  return (
    <View style={{ flex: 1, alignItems: 'center' }}>
      <LinearGradient
        style={{
          alignItems: 'center',
          position: 'absolute',
          left: 0,
          right: 0,
          top: 0,
          height: '100%',
        }}
        colors={['#ffffff', '#ffffff', '#AE040F']}>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text style={{ fontSize: 25, padding: 20 }}>
          Digite seu usuário e senha
        </Text>
        <Text></Text>
        <TextInput
          style={{
            margin: 10,
            padding: 15,
            borderRadius: 10,
            backgroundColor: 'rgba(255,255,255,0.5)',
            width: 300,
            borderWidth: 2,
          }}
          onChangeText={svusuario}
          value={usuario}
          placeholder="Digite seu usuário"
          keyboardType="text"
          placeholderTextColor="#000000"
        />
        <TextInput
          style={{
            margin: 10,
            padding: 15,
            borderRadius: 10,
            backgroundColor: 'rgba(255,255,255,0.5)',
            width: 300,
            borderWidth: 2,
          }}
          onChangeText={svsenha}
          value={senha}
          placeholder="Digite sua senha"
          keyboardType="text"
          placeholderTextColor="#000000"
        />
        <Pressable
          onPress={() => navigation.navigate('HOME')}
          style={{
            margin: 10,
            padding: 15,
            borderRadius: 10,
            backgroundColor: 'rgba(255,255,255,0.5)',
            width: 300,
          }}>
          <Text style={{ textAlign: 'center', fontSize: 22 }}>Entrar</Text>
        </Pressable>
        <Pressable
          onPress={() => navigation.navigate('Login')}
          style={{
            margin: 10,
            padding: 15,
            borderRadius: 10,
            backgroundColor: 'rgba(255,255,255,0.5)',
            width: 300,
          }}>
          <Text style={{ textAlign: 'center', fontSize: 22 }}>Voltar</Text>
        </Pressable>
      </LinearGradient>
    </View>
  );
}

function Cadastrar({ navigation }) {
  const [usuario, svusuario] = React.useState('');
  const [senha, svsenha] = React.useState('');
  return (
    <View style={{ flex: 1, alignItems: 'center' }}>
      <LinearGradient
        style={{
          alignItems: 'center',
          position: 'absolute',
          left: 0,
          right: 0,
          top: 0,
          height: '100%',
        }}
        colors={['#ffffff', '#ffffff', '#AE040F']}>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text style={{ fontSize: 25, padding: 20 }}>Digite seus dados</Text>
        <Text></Text>
        <TextInput
          style={{
            margin: 10,
            padding: 15,
            borderRadius: 10,
            backgroundColor: 'rgba(255,255,255,0.5)',
            width: 300,
            borderWidth: 2,
          }}
          onChangeText={svusuario}
          value={usuario}
          placeholder="Digite um usuário"
          keyboardType="text"
          placeholderTextColor="#000000"
        />
        <TextInput
          style={{
            margin: 10,
            padding: 15,
            borderRadius: 10,
            backgroundColor: 'rgba(255,255,255,0.5)',
            width: 300,
            borderWidth: 2,
          }}
          onChangeText={svsenha}
          value={senha}
          placeholder="Digite uma senha"
          keyboardType="text"
          placeholderTextColor="#000000"
        />
        <Pressable
          onPress={() => navigation.navigate('Login')}
          style={{
            margin: 10,
            padding: 15,
            borderRadius: 10,
            backgroundColor: 'rgba(255,255,255,0.5)',
            width: 300,
          }}>
          <Text style={{ textAlign: 'center', fontSize: 22 }}>Cadastrar</Text>
        </Pressable>
        <Pressable
          onPress={() => navigation.navigate('Login')}
          style={{
            margin: 10,
            padding: 15,
            borderRadius: 10,
            backgroundColor: 'rgba(255,255,255,0.5)',
            width: 300,
          }}>
          <Text style={{ textAlign: 'center', fontSize: 22 }}>Voltar</Text>
        </Pressable>
      </LinearGradient>
    </View>
  );
}

function Home() {
  return (
    <View style={{ flex: 1, alignItems: 'center', backgroundColor: '#fff' }}>
      <Text> </Text>
      <Text> </Text>
      <Image
        source={require('./imagens/telaini.JPG')}
        style={{
          height: 520,
          width: 400,
          resizeMode: 'stretch',
        }}
      />
    </View>
  );
}

function VideoAulas() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <LinearGradient
        style={{
          alignItems: 'center',
          position: 'absolute',
          left: 0,
          right: 0,
          top: 0,
          height: '100%',
        }}
        colors={['#ffffff', '#ffffff', '#AE040F']}>
        <Text>Vídeo Aulas</Text>
      </LinearGradient>
    </View>
  );
}

function Resumos({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center' }}>
      <LinearGradient
        style={{
          alignItems: 'center',
          position: 'absolute',
          left: 0,
          right: 0,
          top: 0,
          height: '100%',
        }}
        colors={['#ffffff', '#ffffff', '#AE040F']}>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Card
          style={{
            height: 195,
            width: 200,
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: 100,
          }}>
          <Card.Content
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              padding: 10,
            }}>
            <Title>Resumos</Title>
            <Text></Text>
            <Image
              source={require('./imagens/resicone.png')}
              style={{
                height: 100,
                width: 100,
                resizeMode: 'stretch',
                paddingTop: 80,
              }}
            />
          </Card.Content>
        </Card>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Pressable
          onPress={() => navigation.navigate('RESUMO 1')}
          style={{
            margin: 10,
            padding: 15,
            borderRadius: 10,
            backgroundColor: 'rgba(255,255,255,0.5)',
            width: 350,
          }}>
          <Text style={{ textAlign: 'center', fontSize: 20 }}>
            Modelos atômicos
          </Text>
        </Pressable>
        <Pressable
          onPress={() => navigation.navigate('RESUMO 2')}
          style={{
            margin: 10,
            padding: 15,
            borderRadius: 10,
            backgroundColor: 'rgba(255,255,255,0.5)',
            width: 350,
          }}>
          <Text style={{ textAlign: 'center', fontSize: 20 }}>
            Estrutura do átomo
          </Text>
        </Pressable>
        <Pressable
          onPress={() => navigation.navigate('RESUMO 3')}
          style={{
            margin: 10,
            padding: 15,
            borderRadius: 10,
            backgroundColor: 'rgba(255,255,255,0.5)',
            width: 350,
          }}>
          <Text style={{ textAlign: 'center', fontSize: 20 }}>
            Distribuição eletrônica
          </Text>
        </Pressable>
        <Pressable
          onPress={() => navigation.navigate('RESUMO 4')}
          style={{
            margin: 10,
            padding: 15,
            borderRadius: 10,
            backgroundColor: 'rgba(255,255,255,0.5)',
            width: 350,
          }}>
          <Text style={{ textAlign: 'center', fontSize: 20 }}>Misturas</Text>
        </Pressable>
      </LinearGradient>
    </View>
  );
}

function Resumo1({ navigation }) {
  return (
    <ScrollView
      style={{ flex: 1, alignItems: 'center', backgroundColor: '#fff9ed' }}>
      <Text></Text>
      <Text></Text>
      <Text></Text>
      <Text></Text>
      <Image
        source={require('./imagens/p1.png')}
        style={{
          height: 500,
          width: 'absolute',
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Image
        source={require('./imagens/p2.png')}
        style={{
          height: 500,
          width: 'absolute',
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Image
        source={require('./imagens/p3.png')}
        style={{
          height: 500,
          width: 'absolute',
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Image
        source={require('./imagens/p4.png')}
        style={{
          height: 500,
          width: 'absolute',
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Image
        source={require('./imagens/p5.png')}
        style={{
          height: 500,
          width: 'absolute',
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Pressable
        onPress={() => navigation.navigate('RESUMOS')}
        style={{
          padding: 15,
          borderRadius: 10,
          width: 390,
        }}>
        <Text style={{ fontSize: 22, textAlign: 'center' }}>Voltar</Text>
      </Pressable>
      <Text></Text>
      <Text></Text>
      <Text></Text>
    </ScrollView>
  );
}

function Resumo2({ navigation }) {
  return (
    <ScrollView
      style={{ flex: 1, alignItems: 'center', backgroundColor: '#fff9ed' }}>
      <Text></Text>
      <Text></Text>
      <Text></Text>
      <Text></Text>
      <Image
        source={require('./imagens/g1.png')}
        style={{
          height: 500,
          width: 385,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Image
        source={require('./imagens/g2.png')}
        style={{
          height: 500,
          width: 390,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Image
        source={require('./imagens/g3.png')}
        style={{
          height: 500,
          width: 390,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Image
        source={require('./imagens/g4.png')}
        style={{
          height: 500,
          width: 390,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Pressable
        onPress={() => navigation.navigate('RESUMOS')}
        style={{
          padding: 15,
          borderRadius: 10,
          width: 390,
        }}>
        <Text style={{ fontSize: 22, textAlign: 'center' }}>Voltar</Text>
      </Pressable>
      <Text></Text>
      <Text></Text>
      <Text></Text>
    </ScrollView>
  );
}

function Resumo3({ navigation }) {
  return (
    <ScrollView
      style={{ flex: 1, alignItems: 'center', backgroundColor: '#fff9ed' }}>
      <Text></Text>
      <Text></Text>
      <Text></Text>
      <Text></Text>
      <Image
        source={require('./imagens/q1.png')}
        style={{
          height: 500,
          width: 385,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Image
        source={require('./imagens/q2.png')}
        style={{
          height: 500,
          width: 390,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Image
        source={require('./imagens/q3.png')}
        style={{
          height: 500,
          width: 390,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Pressable
        onPress={() => navigation.navigate('RESUMOS')}
        style={{
          padding: 15,
          borderRadius: 10,
          width: 390,
        }}>
        <Text style={{ fontSize: 22, textAlign: 'center' }}>Voltar</Text>
      </Pressable>
      <Text></Text>
      <Text></Text>
      <Text></Text>
    </ScrollView>
  );
}

function Resumo4({ navigation }) {
  return (
    <ScrollView
      style={{ flex: 1, alignItems: 'center', backgroundColor: '#fff9ed' }}>
      <Text></Text>
      <Text></Text>
      <Text></Text>
      <Text></Text>
      <Image
        source={require('./imagens/u1.png')}
        style={{
          height: 500,
          width: 385,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Image
        source={require('./imagens/u2.png')}
        style={{
          height: 500,
          width: 390,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Image
        source={require('./imagens/u3.png')}
        style={{
          height: 500,
          width: 390,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Pressable
        onPress={() => navigation.navigate('RESUMOS')}
        style={{
          padding: 15,
          borderRadius: 10,
          width: 390,
        }}>
        <Text style={{ fontSize: 22, textAlign: 'center' }}>Voltar</Text>
      </Pressable>
      <Text></Text>
      <Text></Text>
      <Text></Text>
    </ScrollView>
  );
}

function Exercicios() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <LinearGradient
        style={{
          alignItems: 'center',
          position: 'absolute',
          left: 0,
          right: 0,
          top: 0,
          height: '100%',
        }}
        colors={['#ffffff', '#ffffff', '#AE040F']}>
        <Text>Exercícios</Text>
      </LinearGradient>
    </View>
  );
}

function Experimentos({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center' }}>
      <LinearGradient
        style={{
          alignItems: 'center',
          position: 'absolute',
          left: 0,
          right: 0,
          top: 0,
          height: '100%',
        }}
        colors={['#ffffff', '#ffffff', '#AE040F']}>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Card
          style={{
            height: 200,
            width: 200,
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: 100,
          }}>
          <Card.Content
            style={{
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Text></Text>
            <Title>Experimentos</Title>
            <Text></Text>
            <Image
              source={require('./imagens/expicone.png')}
              style={{
                height: 90,
                width: 100,
                resizeMode: 'stretch',
                paddingTop: 80,
              }}
            />
          </Card.Content>
        </Card>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Text></Text>
        <Pressable
          onPress={() => navigation.navigate('EXPERIMENTO 1')}
          style={{
            margin: 10,
            padding: 15,
            borderRadius: 10,
            backgroundColor: 'rgba(255,255,255,0.5)',
            width: 350,
          }}>
          <Text style={{ textAlign: 'center', fontSize: 20 }}>Magiquímica</Text>
        </Pressable>
        <Pressable
          onPress={() => navigation.navigate('EXPERIMENTO 2')}
          style={{
            margin: 10,
            padding: 15,
            borderRadius: 10,
            backgroundColor: 'rgba(255,255,255,0.5)',
            width: 350,
          }}>
          <Text style={{ textAlign: 'center', fontSize: 20 }}>
            Lâmpada de Lava
          </Text>
        </Pressable>
        <Pressable
          onPress={() => navigation.navigate('EXPERIMENTO 3')}
          style={{
            margin: 10,
            padding: 15,
            borderRadius: 10,
            backgroundColor: 'rgba(255,255,255,0.5)',
            width: 350,
          }}>
          <Text style={{ textAlign: 'center', fontSize: 20 }}>
            Explosão Colorida
          </Text>
        </Pressable>
      </LinearGradient>
    </View>
  );
}

function Experimento1({ navigation }) {
  return (
    <ScrollView
      style={{ flex: 1, alignItems: 'center', backgroundColor: '#fff9ed' }}>
      <Text></Text>
      <Text></Text>
      <Text></Text>
      <Text></Text>
      <Image
        source={require('./imagens/l1.png')}
        style={{
          height: 500,
          width: 385,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Image
        source={require('./imagens/l2.png')}
        style={{
          height: 500,
          width: 390,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Image
        source={require('./imagens/l3.png')}
        style={{
          height: 500,
          width: 390,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Pressable
        onPress={() => navigation.navigate('EXPERIMENTOS')}
        style={{
          padding: 15,
          borderRadius: 10,
          width: 390,
        }}>
        <Text style={{ fontSize: 22, textAlign: 'center' }}>Voltar</Text>
      </Pressable>
      <Text></Text>
      <Text></Text>
      <Text></Text>
    </ScrollView>
  );
}

function Experimento2({ navigation }) {
  return (
    <ScrollView
      style={{ flex: 1, alignItems: 'center', backgroundColor: '#fff9ed' }}>
      <Text></Text>
      <Text></Text>
      <Text></Text>
      <Text></Text>
      <Image
        source={require('./imagens/w1.png')}
        style={{
          height: 500,
          width: 385,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Image
        source={require('./imagens/w2.png')}
        style={{
          height: 500,
          width: 390,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Image
        source={require('./imagens/w3.png')}
        style={{
          height: 500,
          width: 390,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Image
        source={require('./imagens/w4.png')}
        style={{
          height: 500,
          width: 390,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Pressable
        onPress={() => navigation.navigate('EXPERIMENTOS')}
        style={{
          padding: 15,
          borderRadius: 10,
          width: 390,
        }}>
        <Text style={{ fontSize: 22, textAlign: 'center' }}>Voltar</Text>
      </Pressable>
      <Text></Text>
      <Text></Text>
      <Text></Text>
    </ScrollView>
  );
}

function Experimento3({ navigation }) {
  return (
    <ScrollView
      style={{ flex: 1, alignItems: 'center', backgroundColor: '#fff9ed' }}>
      <Text></Text>
      <Text></Text>
      <Text></Text>
      <Text></Text>
      <Image
        source={require('./imagens/r1.png')}
        style={{
          height: 500,
          width: 385,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Image
        source={require('./imagens/r2.png')}
        style={{
          height: 500,
          width: 390,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Image
        source={require('./imagens/r3.png')}
        style={{
          height: 500,
          width: 390,
          resizeMode: 'stretch',
          paddingTop: 70,
        }}
      />
      <Pressable
        onPress={() => navigation.navigate('EXPERIMENTOS')}
        style={{
          padding: 15,
          borderRadius: 10,
          width: 390,
        }}>
        <Text style={{ fontSize: 22, textAlign: 'center' }}>Voltar</Text>
      </Pressable>
      <Text></Text>
      <Text></Text>
      <Text></Text>
    </ScrollView>
  );
}

function MyDrawer() {
  const dimensions = useWindowDimensions();
  return (
    <Drawer.Navigator
      useLegacyImplementation
      initialRouteName="Login"
      screenOptions={{
        drawerStyle: {
          backgroundColor: '#000000',
          width: 240,
          drawerType: dimensions.width >= 768 ? 'permanent' : 'slide',
          overlayColor: 'transparent',
        },
        drawerLabelStyle: {
          fontWeight: 'bold',
          fontColor: '#fff',
        },
        drawerActiveTintColor: '#fff',
        drawerInactiveTintColor: '#fff',
      }}>
      <Drawer.Screen
        name="Login"
        component={Login}
        options={{
          headerShown: false,
          drawerItemStyle: { height: 0 },
          swipeEnabled: false,
        }}
      />

      <Drawer.Screen
        name="Entrar"
        component={Entrar}
        options={{
          headerShown: false,
          drawerItemStyle: { height: 0 },
          swipeEnabled: false,
        }}
      />

      <Drawer.Screen
        name="Cadastrar"
        component={Cadastrar}
        options={{
          headerShown: false,
          drawerItemStyle: { height: 0 },
          swipeEnabled: false,
        }}
      />

      <Drawer.Screen
        name="HOME"
        component={Home}
        options={{
          headerTitle: '',
          headerStyle: {
            backgroundColor: '#000000',
          },
          headerTitleStyle: {
            fontWeight: 'bold',
            fontSize: '15px',
          },
          headerTintColor: '#fff',
        }}
      />
      <Drawer.Screen
        name="RESUMOS"
        component={Resumos}
        options={{
          headerTitle: '',
          headerStyle: {
            backgroundColor: '#000000',
          },
          headerTitleStyle: {
            fontWeight: 'bold',
            fontSize: '0',
          },
          headerTintColor: '#fff',
        }}
      />
      <Drawer.Screen
        name="EXPERIMENTOS"
        component={Experimentos}
        options={{
          headerTitle: '',
          headerStyle: {
            backgroundColor: '#000000',
          },
          headerTitleStyle: {
            fontWeight: 'bold',
            fontSize: '17px',
          },
          headerTintColor: '#fff',
        }}
      />
      <Drawer.Screen
        name="VÍDEO AULAS"
        component={VideoAulas}
        options={{
          headerTitle: '',
          headerStyle: {
            backgroundColor: '#000000',
          },
          headerTitleStyle: {
            fontWeight: 'bold',
            fontSize: '15px',
          },
          headerTintColor: '#fff',
        }}
      />
      <Drawer.Screen
        name="EXERCÍCIOS"
        component={Exercicios}
        options={{
          headerTitle: '',
          headerStyle: {
            backgroundColor: '#000000',
          },
          headerTitleStyle: {
            fontWeight: 'bold',
            fontSize: '17px',
          },
          headerTintColor: '#fff',
        }}
      />
      <Drawer.Screen
        name="RESUMO 1"
        component={Resumo1}
        options={{ headerShown: false, drawerItemStyle: { height: 0 } }}
      />
      <Drawer.Screen
        name="RESUMO 2"
        component={Resumo2}
        options={{ headerShown: false, drawerItemStyle: { height: 0 } }}
      />
      <Drawer.Screen
        name="RESUMO 3"
        component={Resumo3}
        options={{ headerShown: false, drawerItemStyle: { height: 0 } }}
      />
      <Drawer.Screen
        name="RESUMO 4"
        component={Resumo4}
        options={{ headerShown: false, drawerItemStyle: { height: 0 } }}
      />
      <Drawer.Screen
        name="EXPERIMENTO 1"
        component={Experimento1}
        options={{ headerShown: false, drawerItemStyle: { height: 0 } }}
      />
      <Drawer.Screen
        name="EXPERIMENTO 2"
        component={Experimento2}
        options={{ headerShown: false, drawerItemStyle: { height: 0 } }}
      />
      <Drawer.Screen
        name="EXPERIMENTO 3"
        component={Experimento3}
        options={{ headerShown: false, drawerItemStyle: { height: 0 } }}
      />
    </Drawer.Navigator>
  );
}

function App() {
  return (
    <NavigationContainer>
      <MyDrawer />
    </NavigationContainer>
  );
}

export default App;
